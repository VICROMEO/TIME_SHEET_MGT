package com.java.hcl.config;

import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;

@Configuration
public class JsonConfig implements WebMvcConfigurer{


    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
        configurer
            .defaultContentType(MediaType.TEXT_PLAIN)    
            .mediaType("json", MediaType.APPLICATION_JSON);
    }
}
