package com.java.hcl.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.hcl.dao.RegisterDao;
import com.java.hcl.models.RegisterModel;
import com.java.hcl.models.RegisterRequest;

@Service
public class RegisterService {

       private static final Logger logger = LoggerFactory.getLogger(RegisterService.class);

    @Autowired
    private RegisterDao registerdao;

    public String register(RegisterRequest registerModel)
    {
            try
            {
                if(registerModel !=null)
                {
                    RegisterModel model = new RegisterModel();
                    model.setEmail(registerModel.getEmail());
                    model.setPassword(registerModel.getPassword());
                    model.setRoleId(registerModel.getRole());
                    model.setUsername(registerModel.getUsername());

                    registerdao.save(model);
                    return "Success";
                }
            }
            catch(Exception ex)
            {
                    logger.error("Exception in method register", ex);
            }
            return null;
    }

}
