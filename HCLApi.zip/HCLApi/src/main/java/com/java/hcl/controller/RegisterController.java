package com.java.hcl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.java.hcl.models.RegisterRequest;
import com.java.hcl.service.RegisterService;


@RestController
@RequestMapping("/api/v1")
public class RegisterController {

    @Autowired
    private RegisterService registerService;
  @PostMapping(value = "/register", produces = MediaType.APPLICATION_JSON_VALUE)
        public ResponseEntity<?> register(@RequestBody RegisterRequest payload) {
            if (payload != null) {
                Object data = registerService.register(payload);
                return ResponseEntity.ok(data);
            }
            return ResponseEntity.badRequest().body("{\"error\": \"Invalid request\"}");
        }

}
