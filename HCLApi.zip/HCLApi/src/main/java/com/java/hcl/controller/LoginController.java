package com.java.hcl.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;   
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.hcl.models.LoginModel;

@RestController
@RequestMapping("/api/v1/login")                   
public class LoginController {

    @PostMapping("/authenticate")
    public String authenticate(
        @RequestBody LoginModel loginModel             
    ) {
        System.out.println("Received login request: "
            + loginModel.getEmail()
            + " : "
            + loginModel.getPassword()
        );
        return "Login successful for user: " + loginModel.getEmail();
    }
}
