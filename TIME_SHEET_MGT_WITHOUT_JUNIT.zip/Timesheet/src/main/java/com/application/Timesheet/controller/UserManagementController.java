package com.application.Timesheet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.Timesheet.entity.SaveTimeSheetEntity;
import com.application.Timesheet.entity.User;
import com.application.Timesheet.repository.TimeSheetRepo;
import com.application.Timesheet.repository.UserRepo;

@RestController
@RequestMapping("/timesheet")
public class UserManagementController {

	@Autowired
	private TimeSheetRepo timeSheetRepo;

	@Autowired
	UserRepo userRepo;

	@PostMapping("/save")
	public String saveTimeSheetInfo(@RequestBody SaveTimeSheetEntity timesheet) {
		try {
			timeSheetRepo.save(timesheet);
		} catch (Exception e) {
			return "Issue occured while saving the time sheet data";
		}
		return "Successfully saved";

	}

	@PostMapping("/approve")
	public String approveTimeSheetInfo(@RequestBody List<SaveTimeSheetEntity> timesheet) {
		try {
			timeSheetRepo.saveAll(timesheet);
		} catch (Exception e) {
			return "Issue occured while approving the time sheet data";
		}
		return "Updated timesheet";

	}

	@GetMapping("/getTimeSheetInfo")
	public List<SaveTimeSheetEntity> getTimeSheetEntries() throws Exception {
		try {
			return timeSheetRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e);
		}

	}

	@PostMapping("/user")
	public String saveOrModifyUsers(@RequestBody List<User> user) {
		try {
			userRepo.saveAll(user);
		} catch (Exception e) {
			return "Issue occured while saving user data";
		}
		return "User Successfully saved";
	}

	@GetMapping("/getUser")
	public List<User> getUsers() throws Exception {
		try {
			return userRepo.findAll();
		} catch (Exception e) {
			throw new Exception(e);
		}

	}

}
