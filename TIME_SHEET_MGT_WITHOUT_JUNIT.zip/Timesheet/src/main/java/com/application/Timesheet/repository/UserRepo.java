package com.application.Timesheet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.application.Timesheet.entity.User;

public interface UserRepo extends JpaRepository<User, String> {

}
